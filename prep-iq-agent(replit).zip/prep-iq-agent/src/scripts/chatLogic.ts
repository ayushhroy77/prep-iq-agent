const API_BASE = import.meta.env.VITE_API_BASE_URL;
const API_KEY = import.meta.env.VITE_API_KEY;

export interface ChatMessage {
  role: "user" | "assistant" | "system";
  content: string;
  image?: string;
}

export interface ChatPayload {
  messages: ChatMessage[];
}

export interface ChatResponse {
  response: string;
}

export async function askLLM(payload: ChatPayload): Promise<ChatResponse> {
  // Fail fast if environment variables are not configured
  if (!API_BASE || !API_KEY) {
    throw new Error(
      "API configuration missing. Please set VITE_API_BASE_URL and VITE_API_KEY in your environment variables."
    );
  }

  try {
    const response = await fetch(`${API_BASE}/ask`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-API-KEY": API_KEY
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`API Error: ${response.status} - ${errorText}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error calling LLM API:", error);
    throw error;
  }
}
