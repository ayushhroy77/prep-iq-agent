# FastAPI Backend Integration Guide

## Overview

The PrepIQ frontend has been updated to connect to a FastAPI backend via Cloudflare tunnel instead of using Supabase Edge Functions. This allows you to run a local RAG (Retrieval-Augmented Generation) server with your own LLM.

## What Was Changed

### 1. Created `src/scripts/chatLogic.ts`
A new module that handles all API communication with your FastAPI backend:
- Sends POST requests to `${API_BASE}/ask` endpoint
- Includes `X-API-KEY` header for authentication
- Supports text and image payloads
- Implements proper error handling

### 2. Updated `src/pages/AIStudyBuddy.tsx`
The AI Study Buddy page now uses the new `askLLM` function instead of Supabase Functions:
- Builds conversation history with system prompts
- Handles image uploads
- Sends requests to FastAPI backend
- Displays responses in the chat interface

### 3. Added Environment Variables
New environment variables in `.env.example`:
- `VITE_API_BASE_URL` - Your Cloudflare tunnel URL (e.g., https://your-tunnel.trycloudflare.com)
- `VITE_API_KEY` - API key for securing your backend (default: JEE_SECRET_KEY_123)

## Next Steps

### Step 1: Set Up Your Environment Variables

You need to add the following secrets to your Replit project:

1. Click on "Secrets" in the left sidebar (🔒 icon)
2. Add these environment variables:
   - **Name:** `VITE_API_BASE_URL`  
     **Value:** Your Cloudflare tunnel URL (e.g., `https://abc123.trycloudflare.com`)
   
   - **Name:** `VITE_API_KEY`  
     **Value:** Your API key (e.g., `JEE_SECRET_KEY_123`)

**Important:** The application will fail with a clear error message if these are not set.

### Step 2: Set Up Your FastAPI Backend

Your FastAPI backend should implement the following endpoint:

#### POST `/ask`

**Request Headers:**
```
Content-Type: application/json
X-API-KEY: JEE_SECRET_KEY_123
```

**Request Body:**
```json
{
  "messages": [
    {
      "role": "system",
      "content": "You are an expert AI tutor..."
    },
    {
      "role": "user",
      "content": "What is the derivative of sin(x)?",
      "image": "data:image/jpeg;base64,..." (optional)
    }
  ]
}
```

**Response:**
```json
{
  "response": "The derivative of sin(x) is cos(x)..."
}
```

### Step 3: Add CORS and API Key Check to FastAPI

Update your `rag_server.py`:

```python
from fastapi import FastAPI, Header, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI()

# API Key for security
API_KEY = "JEE_SECRET_KEY_123"

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# API Key verification
def check_key(x_api_key: str | None = Header(default=None)):
    if x_api_key != API_KEY:
        raise HTTPException(status_code=403, detail="Forbidden")

# Message model
class Message(BaseModel):
    role: str
    content: str
    image: str | None = None

class QueryRequest(BaseModel):
    messages: list[Message]

# Ask endpoint
@app.post("/ask")
def ask(req: QueryRequest, _=Depends(check_key)):
    # Your RAG logic here
    # Process req.messages and return response
    return {"response": "Your AI response here"}
```

### Step 4: Start Cloudflare Tunnel

In your local machine where the FastAPI backend runs:

```bash
# Start your FastAPI server
python rag_server.py

# In another terminal, start Cloudflare tunnel
cloudflared tunnel --url http://localhost:8000
```

Copy the generated URL (e.g., `https://abc123.trycloudflare.com`) and add it to your Replit secrets.

### Step 5: Test the Integration

1. Make sure your FastAPI backend is running
2. Make sure Cloudflare tunnel is active
3. Add the tunnel URL and API key to Replit secrets
4. Restart the Replit workflow
5. Navigate to the AI Study Buddy page
6. Send a test message

## Expected Data Flow

```
User (Browser)
    ↓
PrepIQ Frontend (Replit)
    ↓ POST /ask with X-API-KEY header
Cloudflare Tunnel
    ↓
FastAPI Backend (Your Local Machine)
    ↓
RAG System / LLM
    ↓ Response
FastAPI Backend
    ↓
Cloudflare Tunnel
    ↓
PrepIQ Frontend
    ↓
Display to User
```

## Troubleshooting

### Error: "API configuration missing"
- Make sure you've added `VITE_API_BASE_URL` and `VITE_API_KEY` to Replit Secrets
- Restart the workflow after adding secrets

### Error: "API Error: 403 - Forbidden"
- Check that your API key matches between frontend and backend
- Verify the `X-API-KEY` header is being sent correctly

### Error: "API Error: 404"
- Verify your FastAPI backend has a `/ask` endpoint
- Check that your Cloudflare tunnel URL is correct

### Error: Connection timeout
- Make sure your FastAPI backend is running
- Verify Cloudflare tunnel is active
- Check firewall settings on your local machine

## Security Notes

1. **Never commit API keys** - Always use environment variables
2. **Use strong API keys** - Replace "JEE_SECRET_KEY_123" with a secure random string
3. **HTTPS only** - Cloudflare tunnels provide HTTPS by default
4. **Rate limiting** - Consider adding rate limiting to your FastAPI backend

## Alternative: Keep Using Supabase

If you prefer to use Supabase Edge Functions instead:

1. Revert the changes to `src/pages/AIStudyBuddy.tsx`
2. Remove the `src/scripts/chatLogic.ts` file
3. The Supabase edge function is already configured at `supabase/functions/chat-ai/index.ts`

The Supabase setup uses the Lovable AI Gateway with Gemini 2.5 Flash model.
