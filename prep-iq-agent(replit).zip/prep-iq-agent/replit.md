# PrepIQ - AI-Powered Study Companion

## Overview

PrepIQ is an intelligent AI-powered exam preparation platform designed to help students ace competitive exams like JEE, NEET, UPSC, CAT, and GATE. The application provides personalized learning experiences through adaptive quizzes, AI tutoring, study scheduling, and comprehensive concept libraries with video resources and study notes.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite with SWC for fast compilation
- **Routing**: React Router DOM for client-side navigation
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **Styling**: Tailwind CSS with custom design system
- **State Management**: TanStack Query (React Query) for server state
- **Form Handling**: React Hook Form with Zod validation

**Design Rationale:**
- React with TypeScript provides type safety and modern component development
- Vite offers extremely fast hot module replacement during development
- Radix UI provides accessible, unstyled primitives that are customized through Tailwind
- TanStack Query handles caching, synchronization, and background updates for server state

### Component Architecture

**UI Library Structure:**
- Custom component library built on Radix UI primitives located in `src/components/ui/`
- Includes 40+ pre-built components (buttons, cards, dialogs, forms, charts, etc.)
- Components follow the "composition over configuration" pattern
- Consistent styling through centralized Tailwind configuration

**Page Components:**
- **Landing**: Marketing page with feature showcase and testimonials
- **Authentication**: Separate registration and login flows with comprehensive validation
- **Dashboard**: Main application hub with analytics, calendar, and quick actions
- **AI Study Buddy**: Chat interface with image upload support for problem-solving
- **Concept Library**: Organized video resources and study notes by subject
- **Study Schedule**: Drag-and-drop schedule builder with subject prioritization
- **Settings**: Comprehensive settings management across multiple categories

### Authentication & Authorization

**Supabase Authentication:**
- Email/password authentication flow
- Session management with automatic token refresh
- Protected routes redirect unauthenticated users to login
- Auth state monitoring across the application

**Security Considerations:**
- Password validation enforces minimum 8 characters, uppercase, and numbers
- Email validation with max length limits
- Phone number format validation with international support
- CSRF protection through Supabase's built-in mechanisms

### Data Management

**Static Data:**
- Educational content stored in JSON files (`modules.json`, `notes.json`)
- Subject categories: Physics, Chemistry, Biology, Mathematics
- YouTube video links mapped to specific topics/modules
- Structured study notes with summaries, key points, and formulas

**State Management Patterns:**
- Server state managed by TanStack Query with automatic caching
- Local component state using React hooks (useState, useEffect)
- Form state managed by React Hook Form with Zod schema validation
- Toast notifications for user feedback using sonner library

### Styling System

**Design System:**
- Custom CSS variables for theming in `src/index.css`
- Color system with semantic tokens (primary, secondary, success, destructive, muted, accent)
- Light/dark mode support through CSS variables
- Gradient backgrounds and glass-morphism effects
- Custom fonts: Outfit for headings, Inter for body text

**Responsive Design:**
- Mobile-first approach with Tailwind breakpoints
- Custom mobile hook (`use-mobile.tsx`) for responsive logic
- Adaptive layouts for different screen sizes
- Touch-optimized interactions for mobile devices

### Interactive Features

**Drag and Drop:**
- @dnd-kit library for study schedule organization
- Sortable subjects and time slots
- Collision detection and smooth animations

**Charts and Visualizations:**
- Recharts integration for performance analytics
- Line charts for progress tracking
- Custom chart components with themed styling

**Image Handling:**
- File upload support in AI Study Buddy
- Base64 image encoding for preview
- Client-side image validation

### Form Validation

**Zod Schema Validation:**
- Comprehensive validation schemas for registration and login
- Real-time field validation with error messages
- Type-safe form data with TypeScript inference
- Custom validation rules for phone numbers, passwords, and multi-select fields

### Routing Structure

**Route Organization:**
- Public routes: Landing, Login, Register, Terms, Privacy
- Protected routes: Dashboard, AI Study Buddy, Concept Library, Study Schedule, Settings
- Catch-all 404 route for undefined paths
- Programmatic navigation using React Router hooks

## External Dependencies

### Core Services

**Supabase (`@supabase/supabase-js`):**
- Backend-as-a-Service platform providing authentication, database, and real-time features
- Used for user authentication and session management
- Configuration through environment variables or default URL

### UI and Styling

**Component Libraries:**
- `@radix-ui/*`: 30+ accessible UI primitive packages (dialogs, dropdowns, tooltips, etc.)
- Provides headless components with full keyboard navigation and ARIA support

**Styling Tools:**
- `tailwindcss`: Utility-first CSS framework
- `autoprefixer`: CSS vendor prefix automation
- `class-variance-authority`: Type-safe component variants
- `tailwind-merge`: Intelligent Tailwind class merging

### State Management & Data Fetching

**TanStack Query (`@tanstack/react-query`):**
- Powerful data synchronization library
- Handles caching, background updates, and request deduplication
- Provides hooks for queries and mutations

### Form Management

**React Hook Form (`react-hook-form`):**
- Performant form library with minimal re-renders
- Works with `@hookform/resolvers` for Zod integration
- Provides form state, validation, and submission handling

**Zod (`zod`):**
- TypeScript-first schema validation
- Used for form validation and type inference
- Integrated with React Hook Form through resolvers

### Utility Libraries

**Date Handling (`date-fns`):**
- Modern date utility library
- Used for calendar operations and date formatting
- Lighter alternative to Moment.js

**Icon Library (`lucide-react`):**
- Comprehensive icon set with React components
- Consistent design language across the application

**Drag and Drop:**
- `@dnd-kit/core`: Modern drag and drop toolkit
- `@dnd-kit/sortable`: Sortable list implementation
- `@dnd-kit/utilities`: Helper functions for DnD

### Development Tools

**Build and Development:**
- `vite`: Next-generation frontend build tool
- `@vitejs/plugin-react-swc`: React plugin using SWC compiler
- `typescript-eslint`: TypeScript linting
- `eslint-plugin-react-hooks`: React Hooks linting rules

**Code Quality:**
- ESLint configuration with recommended rules
- TypeScript strict mode disabled for gradual migration
- Custom linting rules for React Refresh

### Content and Media

**Static Assets:**
- Images stored in `src/assets/` directory
- Educational video content linked from YouTube
- Logo and branding assets
- Feature screenshots and testimonials

### Third-Party Integrations

**Video Resources:**
- YouTube embedded videos for educational content
- External links to curated learning materials
- Subject-specific video playlists

**Fonts:**
- Google Fonts: Outfit and Inter font families
- Loaded via CDN in CSS imports